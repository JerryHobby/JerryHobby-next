import React from 'react'

const HeavyComponent = () => {
  return (
    <div>My Heavy Component</div>
  )
}

export default HeavyComponent