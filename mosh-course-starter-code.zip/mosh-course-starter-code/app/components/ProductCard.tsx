import React from 'react'
import AddToCart from './AddToCart';

const ProductCard = () => {
  return (
    <div>
      <AddToCart />
    </div>
  )
}

export default ProductCard