import React from 'react'

const AdminHomePage = () => {
  return (
    <div>Admin HomePage</div>
  )
}

export default AdminHomePage