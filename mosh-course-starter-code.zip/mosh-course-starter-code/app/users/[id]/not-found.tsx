import React from 'react'

const UserNotFoundPage = () => {
  return (
    <div>This user doesn&apos;t exist.</div>
  )
}

export default UserNotFoundPage