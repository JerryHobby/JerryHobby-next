import React from 'react'

const NotFoundPage = () => {
  return (
    <div>The requested page doesn&apos;t exist.</div>
  )
}

export default NotFoundPage