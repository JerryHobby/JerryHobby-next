import React from 'react'

const Loading = () => {
  return (
    <span className="loading loading-spinner loading-md"></span>
  )
}

export default Loading